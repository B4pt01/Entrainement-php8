<?php
echo "Coucou";
?>

coucou