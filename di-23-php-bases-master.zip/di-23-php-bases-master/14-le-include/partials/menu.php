<nav>
    <ul>
        <li><a href="../maPage.php">accueil</a></li>
        <li><a href="../test.php">test</a></li>
        <li><a href="../test2.php">test2</a></li>
        <li><a href="../test3.php">test3</a></li>
    </ul>
</nav>