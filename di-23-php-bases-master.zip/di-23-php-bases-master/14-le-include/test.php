<?php
include("partials/header.php");
include("partials/menu.php");
?>

    <!-- Content HTML -->

<?php
include("partials/footer.php");
?>