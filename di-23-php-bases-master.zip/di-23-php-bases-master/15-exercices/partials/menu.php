<nav>
    <ul>
        <li class="nav-item"><a href="index.php">Accueil</a></li>
        <li class="nav-item"><a href="exo1.php">Exercice 1</a></li>
        <li class="nav-item"><a href="exo2.php">Exercice 2</a></li>
        <li class="nav-item"><a href="exo3.php">Exercice 3</a></li>
        <li class="nav-item"><a href="exo4.php">Exercice 4</a></li>
        <li class="nav-item"><a href="exo5.php">Exercice 5</a></li>
        <li class="nav-item"><a href="exo6.php">Exercice 6</a></li>
        <li class="nav-item"><a href="exo7.php">Exercice 7</a></li>
        <li class="nav-item"><a href="exo8.php">Exercice 8</a></li>
        <li class="nav-item"><a href="exo9.php">Exercice 9</a></li>
        <li class="nav-item"><a href="exo10.php">Exercice 10</a></li>
        <li class="nav-item"><a href="exo11.php">Exercice 11</a></li>
        <li class="nav-item"><a href="exo12.php">Exercice 12</a></li>
    </ul>
</nav>

