<?php
include("partials/header.php");
include("partials/menu.php");
?>

<?php
include("partials/footer.php");
?>