<?php

$nomDuJoueur1 = "Julien";
$age = 39;
echo "Nom Du joueur 1 : " . $nomDuJoueur1;
echo "<br />";
echo "age Du joueur 1 : " . $age;
echo "<br />";
++$age;
echo "age Du joueur 1 : " . $age;

// Le typage des variables
$nomDujoueur2 = "John";

?>